import React from 'react';

const Welcome = () => {

    return (
        <div className="display-1">Welcome</div>
    )
}
export default Welcome;