import './App.css';
import React, {useState} from 'react'
import Search from './components/Search'
import Result from './components/Result'
import {Router} from '@reach/router'
function App() {
  const [searchInfo, setSearchInfo] = useState({
    category: "people",
    id: "",
  });


  return (
    <div className="container">
      <Search searchInfo={searchInfo} setSearchInfo={setSearchInfo} />

      <Router>
        <Result path="/:category/:id" searchInfo={searchInfo} />
      </Router>
    </div>
  );

}

export default App;


// Second example

// import React, {useState} from 'react';
// import './App.css';
// import Search from './components/Search';
// import Details from './components/Details';

// function App() {

//   const [element, setElement] = useState({});

//   return (
//     <div className="App">
//       <Search setElement={setElement}/>
//       <Details element={element}/>
//     </div>
//   );
// }

// export default App;
