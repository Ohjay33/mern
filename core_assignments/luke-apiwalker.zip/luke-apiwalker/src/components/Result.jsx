import React, { useEffect, useState, } from "react";
import axios from "axios";

const Result = (props) => {

  const { searchInfo, setSearchInfo } = props;
  const [responseData, setResponseData] = useState('');
  const [responseError, setResponseError] = useState(false);

  useEffect(() => {
    axios
      .get(`http://swapi.dev/api/${searchInfo.category}/${searchInfo.id}/`)
      .then((response) => {
        setResponseData(response.data);
        setResponseError(false);
      })
      .catch((error) => {
        setResponseError(true);
      });
  }, [searchInfo])

  return (
    <div>

      {responseError ?
        <>
        <h2 className="display-3 text-center mt-3">"These aren't the droids you're looking for" </h2>
        {/* <img className="img-fluid" src={`${process.env.PUBLIC_URL}/assets/obi.jpg`}  alt="logo"/> */}
        </>
        :

      <ul>
        {Object.entries(responseData).map(([key, value]) => (
          <li className="list-unstyled mt-1">
            <span className="font-weight-bold">{key.replace("_", " ").split(" ").map((s) => s.charAt(0).toUpperCase() + s.substring(1)).join(" ")}:</span>
            <span className="ml-2">{value}</span>
          </li>
        ))}
      </ul>

      }
    </div>
  );
};

export default Result;




// ------> Second example<--------//
//------> "file" Detail.jsx <---------//

// import React, {useEffect, useState} from 'react';
// import Unknown from './Unknown';
// import Axios from 'axios';

// const Details = (props) => {

//     const {element} = props;
//     const [values, setvalues] = useState([]);

//     useEffect(() =>{
//         let temp = []
//         for(let key in element){
//             temp.push({"key": key, "value": element[key]});
//         }
//         setvalues(temp);
//         console.log(temp);
//     }
//     , [element])

//     function getName(url){
//         let name = "";
//         if(url.startsWith('http')){
//             Axios.get(url)
//                 .then( response =>{
//                     return response.data.name;
//                 } );
//         }
//     }


//     return (
//         element.name === "Unknown" ? <Unknown/> : 
//         <div className="container">
//             <div className="row my-3">
//                 <h1>{element.name ? element.name : element.title}</h1>
//             </div>
//             {
//                 values.map((item, idx) =>
//                     <div key={idx} className="row my-2">
//                         <div className="col-3 text-left font-weight-bold">
//                             {item.key}:
//                         </div>
//                         <div className="col-8 text-left">
//                             {item.value}
//                         </div>
//                     </div>
//                 )
//             }
//         </div>
//      );
// }
 
// export default Details;