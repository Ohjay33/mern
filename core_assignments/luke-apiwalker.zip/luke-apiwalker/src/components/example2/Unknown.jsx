

//------> for second example only <---------//


// import React from 'react';

// const Unknown = (props) => {
//     return (
//         <> 
//         <div className="row justify-content-center">
//             <div className="col text-center">
//                 These aren't the droids you are looking for
//             </div>
//         </div>
//         <div className="row justify-content-center">
//             <div className="col text-center">
//                 <img src="Obi-wan_kenobi.jpg" alt="Obi Wan"/>
//             </div>
//         </div>
//         </>
//      );
// }
 
// export default Unknown;